Use './run.sh' in the terminal to run.
The code will not work otherwise



empSorted and deptSorted make the runs.

