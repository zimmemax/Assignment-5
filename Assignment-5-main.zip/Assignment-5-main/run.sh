g++ --std=c++11 sortEmp.cpp 
./a.out 
g++ --std=c++11 sortDept.cpp
./a.out

g++ --std=c++11 main.cpp
./a.out